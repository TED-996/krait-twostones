start "C:\Users\mvasilache\Google Drive\Anul II\ProiectTW+BD\createTables.sql";

start "C:\Users\mvasilache\Google Drive\Anul II\ProiectTW+BD\populateUser.sql";
start "C:\Users\mvasilache\Google Drive\Anul II\ProiectTW+BD\populateTroopclass.sql";
start "C:\Users\mvasilache\Google Drive\Anul II\ProiectTW+BD\populateMap.sql";
start "C:\Users\mvasilache\Google Drive\Anul II\ProiectTW+BD\populateModifiers.sql";
start "C:\Users\mvasilache\Google Drive\Anul II\ProiectTW+BD\populateSkin.sql";
start "C:\Users\mvasilache\Google Drive\Anul II\ProiectTW+BD\populateTroops.sql";