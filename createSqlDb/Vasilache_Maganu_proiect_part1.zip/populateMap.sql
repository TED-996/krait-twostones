BEGIN 
  insert into map values (
    mapIdSeq.nextVal,
    'Dunare'
    );
    
  insert into map values (
    mapIdSeq.nextVal,
    'Campia Romaniei'
    );
    
  insert into map values (
    mapIdSeq.nextVal,
    'Rusia'
    );

END;